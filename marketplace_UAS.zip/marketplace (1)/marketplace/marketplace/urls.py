"""
URL configuration for marketplace project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.http import HttpResponse
from django.shortcuts import render
from dashboard.views import produk
from dashboard.views import kontak
from dashboard.views import about
from dashboard.views import review
from dashboard.views import transaksi
from dashboard.views import pembayaran
from dashboard.views import produk, tambah_barang, Barang_View
from dashboard.views import *
from django.conf.urls.static import static
from django.conf import settings

def main(request):
    titelnya="Home"
    konteks={
        'titelnya' : titelnya,
    }
    
    return render(request, 'home.html', konteks)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', main),
    path('produk',produk),
    path('kontak', kontak),
    path('about',about),
    path('review', review),
    path('transaksi', transaksi),
    path('pembayaran', pembayaran),
    path('add/',tambah_barang),
    path('Vbrg/', Barang_View,name='Vbrg'),
    path('ubah/<int:id_barang>',ubah_brg,name='ubah_brg'),
    path('hapus/<int:id_barang>', hapus_brg,name='hapus_brg'),
    path('profiles/', list_profile, name='list_profile'),
    path('profiles/tambah/', tambah_profile, name='tambah_profile'),
    path('profiles/ubah/<int:id_profile>/', ubah_profile, name='ubah_profile'),
    path('profiles/hapus/<int:id_profile>/', hapus_profile, name='hapus_profile'),
    path('profiles/<int:id_profile>/', detail_profile, name='detail_profile'),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
