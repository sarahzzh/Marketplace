<script>
        // Ambil elemen ikon hati
        
        var likeButton = document.getElementById("likeButton");

        // Tambahkan event listener untuk menangani klik
        likeButton.addEventListener("click", function() {
            // Toggle kelas 'liked' untuk mengganti warna ikon
            likeButton.classList.toggle("liked")
        });
    </script>