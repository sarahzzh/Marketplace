from django.shortcuts import render
from dashboard.forms import FormBarang
from dashboard.models import Barang
from django.contrib import messages
from django.shortcuts import render,redirect, get_object_or_404
from .models import Profile
from .forms import ProfileForm

# Create your views here.

def tambah_barang(request):
    if request.POST:
        form = FormBarang(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, 'Data berhasil ditambahkan')
            form = FormBarang()
            konteks ={
                'form': form,
            }
            return render(request,'tambah_barang.html', konteks) 
    else:
        form = FormBarang()
        konteks = {
            'form':form,
        }
        return render(request, 'tambah_barang.html', konteks)

def produk(request):
    titelnya="Produk"
    konteks={
        'titel' : titelnya,
    }
    
    return render(request, 'produk.html', konteks)

def Barang_View(request):
    barangs=Barang.objects.all()
    
    konteks={
        'barangs':barangs,
    }
    return render(request, 'tampil_brg.html', konteks)

def ubah_brg(request, id_barang):
    barangs = get_object_or_404(Barang, id=id_barang)
    
    if request.method == 'POST':
        form = FormBarang(request.POST, request.FILES, instance=barangs)
        if form.is_valid():
            form.save()
            messages.success(request, 'Data berhasil diubah')
            return redirect('Vbrg')
    else:
        form = FormBarang(instance=barangs)
    
    konteks = {
        'form': form,
        'barangs': barangs,
    }
    return render(request, 'ubah_brg.html', konteks)
        

def hapus_brg(request,id_barang):
    barangs=Barang.objects.filter(id=id_barang)
    barangs.delete()
    messages.success(request,"Data Terhapus")
    return redirect('Vbrg')

def tambah_profile(request):
    if request.method == 'POST':
        form = ProfileForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, 'Profile berhasil ditambahkan')
            return redirect('list_profile')
    else:
        form = ProfileForm()
    
    return render(request, 'tambah_profile.html', {'form': form})

def detail_profile(request, id_profile):
    profile = get_object_or_404(Profile, id=id_profile)
    return render(request, 'detail_profile.html', {'profile': profile})

def ubah_profile(request, id_profile):
    profile = get_object_or_404(Profile, id=id_profile)
    
    if request.method == 'POST':
        form = ProfileForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, 'Profile berhasil diubah')
            return redirect('list_profile')
    else:
        form = ProfileForm(instance=profile)
    
    return render(request, 'ubah_profile.html', {'form': form})

def hapus_profile(request, id_profile):
    profile = get_object_or_404(Profile, id=id_profile)
    
    if request.method == 'POST':
        profile.delete()
        messages.success(request, 'Profile berhasil dihapus')
        return redirect('list_profile')
    
    return render(request, 'hapus_profile.html', {'profile': profile})

def list_profile(request):
    profiles = Profile.objects.all()
    return render(request, 'list_profile.html', {'profiles': profiles})

def kontak(request):
    titelnya='Kontak'
    konteks={
        'titel' : titelnya,
    }
    
    return render(request,'kontak.html', konteks)

def about(request):
    titelnya='About'
    konteks={
        'titel' : titelnya,
    }
    
    return render(request,'about.html', konteks)


def review(request):
    titelnya='Review'
    konteks={
        'titel' : titelnya,
    }
    
    return render(request,'review.html', konteks)

def transaksi(request):
    titelnya='Transaksi'
    konteks={
        'titel' : titelnya,
    }
    
    return render(request,'transaksi.html', konteks)

def pembayaran(request):
    titelnya='Payment'
    konteks={
        'titel' : titelnya,
    }
    
    return render(request,'pembayaran.html', konteks)


