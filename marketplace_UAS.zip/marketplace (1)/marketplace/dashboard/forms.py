from django.forms import ModelForm
from dashboard.models import Barang
from django import forms
from .models import Profile

class FormBarang(ModelForm):
    class Meta :
        model=Barang
        fields='__all__'
        
        widgets ={
            'kodebrg': forms.TextInput({'class':'form-control'}),
            'nama' : forms.TextInput({'class':'form-control'}),
            'stok': forms.NumberInput({'class' : 'form-control'}),
            'harga': forms.NumberInput({'class' : 'form-control'}),
            'image' : forms.ClearableFileInput(attrs={'class': 'form-control'}),
            'jenis_id': forms.Select({'class':'form-control'}),
        }

class ProfileForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ['nama', 'foto', 'bio', 'email', 'no_hp', 'jenis_kelamin']
        
        widgets = {
            'nama': forms.TextInput(attrs={'class': 'form-control'}),
            'foto' : forms.ClearableFileInput(attrs={'class': 'form-control'}),
            'bio': forms.Textarea(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
            'no_hp': forms.TextInput(attrs={'class': 'form-control'}),
            'jenis_kelamin': forms.Select(attrs={'class': 'form-control'}),
        }